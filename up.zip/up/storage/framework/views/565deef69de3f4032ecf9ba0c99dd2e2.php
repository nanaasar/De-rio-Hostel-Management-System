<div style="font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial;">
    <h2>Booking received</h2>
    <p>Thank you, <?php echo e($booking->name); ?>. We received your booking request for <strong><?php echo e($booking->room_type); ?></strong>.</p>
    <p>Check-in: <?php echo e($booking->check_in); ?> — Check-out: <?php echo e($booking->check_out); ?></p>
    <p>We will review your submission and contact you shortly.</p>
</div>
<?php /**PATH C:\xampp\htdocs\de-rio\resources\views\emails\booking_submitted.blade.php ENDPATH**/ ?>