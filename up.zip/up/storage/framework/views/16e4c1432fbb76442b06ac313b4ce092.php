<div style="font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial;">
    <h2>Your booking was approved</h2>
    <p>Hello <?php echo e($booking->name); ?>,</p>
    <p>Your booking for <strong><?php echo e($booking->room_type); ?></strong> has been approved.</p>
    <p>Check-in: <?php echo e($booking->check_in); ?> — Check-out: <?php echo e($booking->check_out); ?></p>
    <p>Thank you.</p>
</div>
<?php /**PATH C:\xampp\htdocs\de-rio\resources\views\emails\booking_approved.blade.php ENDPATH**/ ?>